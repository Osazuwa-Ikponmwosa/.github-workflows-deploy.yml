# Resume Overview

**Name:** Osazuwa Ikponmwosa  
**Email:** osaze.ikponmwosa@gmail.com  
**LinkedIn:** https://www.linkedin.com/in/YOUR-LINKEDIN

## Summary
IT professional with 5+ years spanning technical support, IT compliance, and data analysis. UTA graduate (B.S. IT).

## Experience
- **Asurion** — Technical Support Analyst (May 2024–Present)
- **TeleMD** — Consulting Associate (Mar 2021–Feb 2024)
- **Bloom Insurance Agency** — Data Analyst (Jan 2019–Mar 2021)

## Skills
NIST 800-53/800-137, SSP/RA/PIA/POA&M, incident tracking, risk assessment, process automation, customer communication.