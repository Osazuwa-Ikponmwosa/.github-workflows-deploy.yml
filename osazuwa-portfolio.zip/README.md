# osazuwa-portfolio

Personal IT portfolio of Osazuwa Ikponmwosa — showcasing expertise in technical support, data analysis, and IT compliance. Built with React & TailwindCSS, featuring projects, resume highlights, and contact info for professional collaboration.

**Live URL (after publishing):** https://Osazuwa-Ikponmwosa.github.io/osazuwa-portfolio/

## Local dev
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Deploy (GitHub Pages via Actions)
Pushing to `main` triggers the GitHub Action in `.github/workflows/deploy.yml` which publishes `dist/` to `gh-pages`.

---

### Projects
- IT Compliance Dashboard — conceptual visualization for NIST 800-53 control tracking
- Incident Response Workflow — process templates for triage and escalation
