# Incident Response Workflow

**Objective:** Document a repeatable workflow for incident handling from ticket creation to closure.  
**Framework:** NIST 800-61 guidance (conceptual alignment).  
**Highlights:**
- Triage categories, SLAs, and escalation paths
- Root cause analysis checklist
- Post-incident review template