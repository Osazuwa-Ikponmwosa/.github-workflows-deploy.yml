# IT Compliance Dashboard

**Objective:** Visualize and monitor NIST 800-53 compliance controls for SMBs.  
**Stack:** React (front-end concept), JSON data model, CSV import.  
**Highlights:**
- Control mapping templates (ID, status, evidence, owner, review date)
- Progress visualization with simple charts (conceptual)
- Export-ready summaries for audits