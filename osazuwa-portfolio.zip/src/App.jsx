
import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
        <nav className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="#hero" className="font-bold text-lg">OI</a>
          <div className="space-x-4 text-sm">
            <a href="#about" className="hover:underline">About</a>
            <a href="#skills" className="hover:underline">Skills</a>
            <a href="#experience" className="hover:underline">Experience</a>
            <a href="#projects" className="hover:underline">Projects</a>
            <a href="#press" className="hover:underline">Press</a>
            <a href="#contact" className="hover:underline">Contact</a>
          </div>
        </nav>
      </header>

      <main id="main-content">
        <section id="hero" aria-labelledby="intro-title" className="text-center py-20 bg-gradient-to-r from-blue-600 to-indigo-700 text-white">
          <h1 id="intro-title" className="text-4xl md:text-6xl font-extrabold">Osazuwa Ikponmwosa</h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg">
            Information Technology Professional — technical support, data analysis, and IT compliance (NIST). Graduate of the University of Texas at Arlington.
          </p>
          <div className="mt-6 space-x-3">
            <a href="mailto:osaze.ikponmwosa@gmail.com" className="bg-white text-blue-700 px-4 py-2 rounded-lg font-medium hover:bg-blue-100">Email</a>
            <a href="https://www.linkedin.com/in/YOUR-LINKEDIN" target="_blank" rel="noopener noreferrer" className="border border-white px-4 py-2 rounded-lg font-medium hover:bg-white hover:text-blue-700">LinkedIn</a>
            <a href="#press" className="border border-white px-4 py-2 rounded-lg font-medium hover:bg-white hover:text-blue-700">Press</a>
          </div>
        </section>

        <section id="about" aria-labelledby="about-title" className="py-16 px-6 md:px-8 max-w-5xl mx-auto bg-white">
          <h2 id="about-title" className="text-3xl font-semibold mb-4">About</h2>
          <p className="text-lg leading-relaxed">
            I’m a graduate of the <strong>University of Texas at Arlington</strong> with a B.S. in Information Technology and 5+ years across technical support,
            compliance documentation, and data analysis. I build reliable, secure, and user-friendly systems by combining troubleshooting expertise with
            process improvement and clear communication.
          </p>
        </section>

        <section id="skills" aria-labelledby="skills-title" className="py-16 px-6 md:px-8 max-w-5xl mx-auto">
          <h2 id="skills-title" className="text-3xl font-semibold mb-6">Skills</h2>
          <ul className="grid grid-cols-2 md:grid-cols-3 gap-3 text-base">
            <li>IT Support & Troubleshooting</li>
            <li>Data Analysis & Reporting</li>
            <li>Incident Tracking</li>
            <li>Risk Assessment</li>
            <li>Process Automation</li>
            <li>NIST 800-53 & 800-137</li>
            <li>Documentation (SSP, RA, PIA, POA&M)</li>
            <li>CRM & Ticketing Systems</li>
            <li>Customer Communication</li>
          </ul>
        </section>

        <section id="experience" aria-labelledby="exp-title" className="py-16 px-6 md:px-8 max-w-5xl mx-auto bg-white">
          <h2 id="exp-title" className="text-3xl font-semibold mb-8">Experience</h2>
          <div className="space-y-8">
            <article>
              <h3 className="text-2xl font-bold">Technical Support Analyst — Asurion</h3>
              <p className="text-gray-600 italic">May 2024 – Present · Houston, TX</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Diagnose and resolve multi-platform device issues with top-tier CSAT.</li>
                <li>Analyze recurring incidents; document high-frequency fixes to reduce repeats.</li>
                <li>Deliver data-informed workflow improvements to enhance resolution times.</li>
              </ul>
            </article>
            <article>
              <h3 className="text-2xl font-bold">Consulting Associate — TeleMD</h3>
              <p className="text-gray-600 italic">Mar 2021 – Feb 2024 · Remote</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Maintained security documentation (SSP, RA, PIA) and POA&Ms.</li>
                <li>Conducted compliance analysis aligned with NIST 800-53 and 800-137.</li>
                <li>Improved audit readiness and policy alignment across teams.</li>
              </ul>
            </article>
            <article>
              <h3 className="text-2xl font-bold">Data Analyst — Bloom Insurance Agency</h3>
              <p className="text-gray-600 italic">Jan 2019 – Mar 2021 · Bloomington, IN</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Supported data system design for claims processing; strengthened DR planning.</li>
                <li>Identified performance trends and vulnerabilities; trained teams on best practices.</li>
              </ul>
            </article>
          </div>
        </section>

        <section id="projects" aria-labelledby="proj-title" className="py-16 px-6 md:px-8 max-w-5xl mx-auto">
          <h2 id="proj-title" className="text-3xl font-semibold mb-6">Projects</h2>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="border p-6 rounded-2xl shadow-sm hover:shadow-md transition">
              <h3 className="text-xl font-bold mb-2">IT Compliance Dashboard</h3>
              <p className="text-gray-700 mb-2">Concept to visualize NIST 800-53 control tracking for SMB compliance.</p>
              <a className="text-blue-700 hover:underline" href="https://github.com/Osazuwa-Ikponmwosa" target="_blank" rel="noreferrer">View on GitHub →</a>
            </div>
            <div className="border p-6 rounded-2xl shadow-sm hover:shadow-md transition">
              <h3 className="text-xl font-bold mb-2">Incident Response Workflow</h3>
              <p className="text-gray-700 mb-2">Process templates to triage, escalate, and resolve incidents efficiently.</p>
              <a className="text-blue-700 hover:underline" href="https://github.com/Osazuwa-Ikponmwosa" target="_blank" rel="noreferrer">View on GitHub →</a>
            </div>
          </div>
        </section>

        <section id="press" aria-labelledby="press-title" className="py-16 px-6 md:px-8 max-w-5xl mx-auto bg-white">
          <h2 id="press-title" className="text-3xl font-semibold mb-6">Press</h2>
          <p className="mb-4">Ready-to-share announcement about my career focus and recent work:</p>
          <a className="text-blue-700 hover:underline break-all" href="https://Osazuwa-Ikponmwosa.github.io/osazuwa-portfolio/press/osazuwa-ikponmwosa-career-update.html">
            https://Osazuwa-Ikponmwosa.github.io/osazuwa-portfolio/press/osazuwa-ikponmwosa-career-update.html
          </a>
        </section>

        <section id="contact" aria-labelledby="contact-title" className="py-16 px-6 md:px-8 max-w-5xl mx-auto text-center">
          <h2 id="contact-title" className="text-3xl font-semibold mb-4">Get in Touch</h2>
          <p className="mb-2">Email: <a href="mailto:osaze.ikponmwosa@gmail.com" className="text-blue-700 hover:underline">osaze.ikponmwosa@gmail.com</a></p>
          <p><a className="text-blue-700 hover:underline" href="https://www.linkedin.com/in/YOUR-LINKEDIN" target="_blank" rel="noreferrer">LinkedIn Profile</a></p>
        </section>
      </main>

      <footer className="text-center py-6 bg-gray-100 text-gray-600">
        <p>© {new Date().getFullYear()} Osazuwa Ikponmwosa · Built with React & TailwindCSS</p>
      </footer>
    </div>
  );
}
